#include <linux/types.h>
#include <linux/fs.h>
#include <linux/printk.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/module.h>
#include <linux/init.h>
#include <asm/uaccess.h>

#include <mach/gpio.h>
#include <mach/regs-gpio.h>
#include <plat/gpio-cfg.h>
#include <asm/uaccess.h>

#define DEVICE_NAME "four_leds"
#define N_D 4
#define S_N 1
#define LED_ON 0
#define LED_OFF 1
#define LED1 S5PV210_GPJ2(0)
#define LED2 S5PV210_GPJ2(1)
#define LED3 S5PV210_GPJ2(2)
#define LED4 S5PV210_GPJ2(3)

static unsigned int LED[] = {LED1, LED2, LED3, LED4};
static dev_t devno;
static int major;
static int minor;
static struct cdev dev_four_leds;

static int four_leds_open(struct inode *inode, struct file *fp){
  minor = MINOR(inode->i_rdev);
  printk("Device " DEVICE_NAME " open minor = %d.\n", minor);
  return 0;
}

static ssize_t four_leds_write(struct file *fp, const char *buf, size_t count, loff_t *position){
  char led_status;
  int ret;
  ret = copy_from_user(&led_status, buf, sizeof(led_status));
  if (ret){
    printk("Fail to copy data from the user space to the kernel space.\n");
    return -1;
  }
  printk("Write: led = 0x%x, count = %d.\n", led_status, count);
  if (led_status > '0')
    gpio_set_value(LED[minor-S_N], LED_ON);
  else
    gpio_set_value(LED[minor-S_N], LED_OFF);
  return sizeof(led_status);
}

static int four_leds_release(struct inode * inode, struct file * fp){
  printk("Device " DEVICE_NAME " release.\n");
  return 0;
}

static struct file_operations four_leds_fops = {
  owner: THIS_MODULE, 
  open: four_leds_open,
  write: four_leds_write,
  release: four_leds_release,
};


static int __init four_leds_init(void){
  int ret;

  s3c_gpio_cfgpin(LED1, S3C_GPIO_OUTPUT);
  gpio_set_value(LED1, LED_OFF);
  s3c_gpio_cfgpin(LED2, S3C_GPIO_OUTPUT);
  gpio_set_value(LED2, LED_OFF);
  s3c_gpio_cfgpin(LED3, S3C_GPIO_OUTPUT);
  gpio_set_value(LED3, LED_OFF);
  s3c_gpio_cfgpin(LED4, S3C_GPIO_OUTPUT);
  gpio_set_value(LED4, LED_OFF);

  ret = alloc_chrdev_region(&devno, S_N, N_D, DEVICE_NAME);
  if (ret < 0){
    printk("Device " DEVICE_NAME " cannot get major number.\n");
    return ret;
  }

  major = MAJOR(devno);
  printk("Device " DEVICE_NAME " get major number %d.\n", major);

  cdev_init(&dev_four_leds, &four_leds_fops);
  dev_four_leds.owner = THIS_MODULE;
  dev_four_leds.ops = &four_leds_fops;
  ret = cdev_add(&dev_four_leds, devno, N_D);

  if (ret){
    printk("Device " DEVICE_NAME " cannot be registered.\n");
    return ret;
  }
  printk("Device " DEVICE_NAME " loaded.\n");
  return 0;
}

static void __exit four_leds_exit(void){
  cdev_del(&dev_four_leds);
  unregister_chrdev_region(devno, N_D);
  printk("Device " DEVICE_NAME " unloaded.\n");
}

module_init(four_leds_init);
module_exit(four_leds_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Dr. Zili Shao");
MODULE_DESCRIPTION("4 LEDS");
