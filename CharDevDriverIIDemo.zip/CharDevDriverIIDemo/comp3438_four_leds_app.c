#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main(){
  int fd;
  char input[4];
  char y;
  
  while(1){
    printf("Input the leds control commands: '0' for off, '1' for on.\n");
    scanf(" %c %c %c %c", input, input+1, input+2, input+3);
    
    fd = open("/dev/led_1", O_WRONLY);
    if (fd == -1){
      perror("Fail to open led_1.\n");
      exit(-1);
    }
    write(fd, &input[0], 1);

    fd = open("/dev/led_2", O_WRONLY);
    if (fd == -1){
      perror("Fail to open led_2.\n");
      exit(-1);
    }
    write(fd, &input[1], 1);

    fd = open("/dev/led_3", O_WRONLY);
    if (fd == -1){
      perror("Fail to open led_3.\n");
      exit(-1);
    }
    write(fd, &input[2], 1);

    fd = open("/dev/led_4", O_WRONLY);
    if (fd == -1){
      perror("Fail to open led_4.\n");
      exit(-1);
    }
    write(fd, &input[3], 1);

    printf("Exit? ('y' for exiting)");
    scanf(" %c", &y);
    if (y == 'y') break;
  }
}
  
  
