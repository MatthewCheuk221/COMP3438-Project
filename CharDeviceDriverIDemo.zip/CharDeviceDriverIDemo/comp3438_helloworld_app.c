#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main(){
  int fd;
  int count;
  char buf[100];

  fd = open("/dev/helloworld", O_RDONLY);
  if (fd == -1){
    printf("Fail to open device helloworld.\n");
    exit(-1);
  }

  count = read(fd, buf, 99);
  buf[count] = '\0';
  printf("%d %s\n", count, buf);

  close(fd);
  return 0;
}
  

