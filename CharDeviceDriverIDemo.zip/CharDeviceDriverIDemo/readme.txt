The Hello World Device Driver Source Code:
	comp3438_helloworld.c

The Hello World Device Driver Testing Application Source Code:
	comp3438_helloworld_app.c
